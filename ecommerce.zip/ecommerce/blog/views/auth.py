
from django.contrib import messages
from django.shortcuts import render, redirect
from django.contrib.auth import logout, authenticate, login
from django.urls import reverse

from blog.forms import LoginForm, RegisterForm, EmailForm
from blog.models import User
from django.core.mail import send_mail
from config.settings import DEFAULT_FROM_EMAIL

def login_page(request):
    form = LoginForm()
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            user = authenticate(request, email=email, password=password)
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return redirect('index')
            else:
                messages.add_message(
                    request,
                    level=messages.WARNING,
                    message='User not found'

                )

    return render(request, 'blog/auth/login.html', {'form': form})


def logout_page(request):
    if request.method == 'GET':
        logout(request)
        return redirect(reverse('index'))
    return render(request, 'blog/auth/logout.html')


def register(request):
    form = RegisterForm()
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            first_name = form.cleaned_data.get('first_name')
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            user = User.objects.create_user(first_name=first_name, email=email, password=password)
            user.is_active = True
            user.is_staff = True
            user.is_superuser = True
            user.save()
            send_mail(
                'Programming',
                'Test message',
                DEFAULT_FROM_EMAIL,
                [email],
                fail_silently=False
            )
            login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            return redirect('index')

    return render(request, 'blog/auth/register.html', {'form': form})


def sending_email(request):
    form = EmailForm()
    if request.method == 'GET':
        subject = request.GET.get('subject')
        message = request.GET.get('message')
        from_email = request.GET.get('from_email')
        to = request.GET.get('to')
        send_mail(subject, message, from_email, [to])
    return render(request, 'blog/sending-email.html', {'form': form})
    